/*
 * Inventory App
 * Developed by Mattthew Neale
 * Version 1.0
 * last updated 6/23/2021
 */
package com.mneale.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mneale.inventoryapp.model.Item;

public class AddActivity extends AppCompatActivity implements View.OnClickListener {
    private final AppCompatActivity activity = AddActivity.this;

    // views and buttons
    private EditText textInputItemName;
    private EditText textInputItemDescription;
    private EditText textInputItemQuantity;
    private Button buttonConfirm;
    private InventoryDatabase inventoryDatabase;
    private Item item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        initializeViews();
        initializeListeners();
        initializeObjects();
    }

    // initialize the views
    private void initializeViews() {
        textInputItemName = findViewById(R.id.addItemText);
        textInputItemDescription = findViewById(R.id.addItemDescription);
        textInputItemQuantity = findViewById(R.id.addItemQuantity);
        buttonConfirm = findViewById(R.id.confirmButton);
    }

    // initialize the listeners
    private void initializeListeners() {
        buttonConfirm.setOnClickListener(this);
    }

    // initialize database and other objects
    private void initializeObjects() {
        inventoryDatabase = new InventoryDatabase(activity);
        item = new Item();
    }

    // method to add an item to inventory database
    // utilizes addItem() and checkItem() from InventoryDatabase class
    private boolean addToDatabase() {
        // check that no input is empty
        if (TextUtils.isEmpty(textInputItemName.getText().toString().trim()) || TextUtils.isEmpty(textInputItemDescription.getText().toString().trim()) ||
                TextUtils.isEmpty(textInputItemQuantity.getText().toString().trim())) {
            Toast.makeText(getApplicationContext(), getString(R.string.error_missing_info), Toast.LENGTH_LONG).show();
            return false;
        // check that quantity is an integer
        } else if (!android.text.TextUtils.isDigitsOnly(textInputItemQuantity.getText().toString().trim())) {
            Toast.makeText(getApplicationContext(), getString(R.string.error_quantity), Toast.LENGTH_LONG).show();
            return false;
        // check if item already exists in database
        } else if (!inventoryDatabase.checkItem(textInputItemName.getText().toString().trim())) {
            item.setName(textInputItemName.getText().toString().trim());
            item.setDescription(textInputItemDescription.getText().toString().trim());
            item.setQuantity(textInputItemQuantity.getText().toString().trim());

            inventoryDatabase.addItem(item);
            return true;
        } else {
            Toast.makeText(getApplicationContext(), getString(R.string.error_item_exists), Toast.LENGTH_LONG).show();
            return false;
        }
    }

    // method to handle button clicks
    public void onClick(View view) {
        // confirm button to login and go to main InventoryActivity
        if (view.getId() == R.id.confirmButton) {
            if (addToDatabase()) {
                Intent intent = new Intent(this, InventoryActivity.class);
                intent.putExtra("USERNAME", InventoryActivity.getNameFromIntent());
                startActivity(intent);
            }
        }
    }
}