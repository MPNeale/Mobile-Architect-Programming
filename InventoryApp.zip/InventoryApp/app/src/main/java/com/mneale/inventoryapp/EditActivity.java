/*
 * Inventory App
 * Developed by Mattthew Neale
 * Version 1.0
 * last updated 6/23/2021
 */
package com.mneale.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mneale.inventoryapp.model.Item;

public class EditActivity extends AppCompatActivity implements View.OnClickListener {
    private final AppCompatActivity activity = EditActivity.this;

    // views and buttons
    private int itemID;
    private EditText textInputItemName;
    private EditText textInputItemDescription;
    private EditText textInputItemQuantity;
    private Button buttonConfirm;
    private InventoryDatabase inventoryDatabase;
    private Item item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        initializeViews();
        initializeListeners();
        initializeObjects();
    }

    // initialize the views
    private void initializeViews() {
        textInputItemName = findViewById(R.id.editItemText);
        textInputItemDescription = findViewById(R.id.editItemDescription);
        textInputItemQuantity = findViewById(R.id.editItemQuantity);
        buttonConfirm = findViewById(R.id.editConfirmButton);
    }

    // initialize the listeners
    private void initializeListeners() {
        buttonConfirm.setOnClickListener(this);
    }

    // initialize the database and other objects
    private void initializeObjects() {
        inventoryDatabase = new InventoryDatabase(activity);
        int idFromIntent = getIntent().getIntExtra("ITEM_ID", 0);
        String nameFromIntent = getIntent().getStringExtra("ITEM_NAME");
        String descFromIntent = getIntent().getStringExtra("ITEM_DESC");
        String quanFromIntent = getIntent().getStringExtra("ITEM_QUAN");
        itemID = idFromIntent;
        textInputItemName.setText(nameFromIntent);
        textInputItemDescription.setText(descFromIntent);
        textInputItemQuantity.setText(quanFromIntent);
        item = new Item();
    }

    // method to update an item in the inventory database
    // utilizes updateItem() method from InventoryDatabase class
    private boolean updateDatabase() {
        // check that no input is empty
        if (TextUtils.isEmpty(textInputItemName.getText().toString().trim()) || TextUtils.isEmpty(textInputItemDescription.getText().toString().trim()) ||
                TextUtils.isEmpty(textInputItemQuantity.getText().toString().trim())) {
            Toast.makeText(getApplicationContext(), getString(R.string.error_missing_info), Toast.LENGTH_LONG).show();
            return false;
        // check that quantity is an integer
        } else if (!android.text.TextUtils.isDigitsOnly(textInputItemQuantity.getText().toString().trim())) {
            Toast.makeText(getApplicationContext(), getString(R.string.error_quantity), Toast.LENGTH_LONG).show();
            return false;
        // set and update item
        } else {
            item.setId(itemID);
            item.setName(textInputItemName.getText().toString().trim());
            item.setDescription(textInputItemDescription.getText().toString().trim());
            item.setQuantity(textInputItemQuantity.getText().toString().trim());

            inventoryDatabase.updateItem(item);
            return true;
        }
    }

    // handles button clicks
    public void onClick(View view) {
        // confirm input and return to main InventoryActivity
        if (view.getId() == R.id.editConfirmButton) {
            if (updateDatabase()) {
                Intent intent = new Intent(this, InventoryActivity.class);
                intent.putExtra("USERNAME", InventoryActivity.getNameFromIntent());
                startActivity(intent);
            }
        }
    }
}