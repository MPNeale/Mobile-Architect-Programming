/*
 * Inventory App
 * Developed by Mattthew Neale
 * Version 1.0
 * last updated 6/23/2021
 */
package com.mneale.inventoryapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.mneale.inventoryapp.model.Item;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.mneale.inventoryapp.SettingsActivity.mPhoneNumber;

public class InventoryActivity extends AppCompatActivity implements View.OnClickListener{

    private final AppCompatActivity activity = InventoryActivity.this;

    // views and buttons
    private TextView textViewName;
    private RecyclerView recyclerViewItems;
    private List<Item> listItems;
    private ItemsRecyclerAdapter itemsRecyclerAdapter;
    private InventoryDatabase inventoryDatabase;
    private Button addItemButton;
    private Button clearInventoryButton;
    public static String nameFromIntent;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        Objects.requireNonNull(getSupportActionBar()).setTitle("");

        initializeViews();
        initializeListeners();
        initializeObjects();
    }
    // initialize the views
    private void initializeViews() {
        // views
        textViewName = findViewById(R.id.textViewName);
        recyclerViewItems = findViewById(R.id.recyclerViewItems);
        addItemButton = findViewById(R.id.addItemButton);
        clearInventoryButton = findViewById(R.id.clearInventoryButton);
    }
    // initialize listeners
    private void initializeListeners() {
        addItemButton.setOnClickListener(this);
        clearInventoryButton.setOnClickListener(this);
    }
    // initialize objects
    private void initializeObjects() {
        listItems = new ArrayList<>();
        itemsRecyclerAdapter = new ItemsRecyclerAdapter(listItems);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerViewItems.setLayoutManager(mLayoutManager);
        recyclerViewItems.setItemAnimator(new DefaultItemAnimator());
        recyclerViewItems.setHasFixedSize(true);
        recyclerViewItems.setAdapter(itemsRecyclerAdapter);
        inventoryDatabase = new InventoryDatabase(activity);
        nameFromIntent = getIntent().getStringExtra("USERNAME");
        textViewName.setText(nameFromIntent);
        getDataFromDatabase();
    }
    // hold username for greeting
    public static String getNameFromIntent() {
        return nameFromIntent;
    }
    // create settings menu button on app bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.settings_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int id = menuItem.getItemId();

        if (id == R.id.settings) {
            Intent intentSettings = new Intent(this, SettingsActivity.class);
            startActivity(intentSettings);
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    // get item data from database to display in recyclerview
    // Utilizes getAllItems from InventoryDatabase
    @SuppressLint("StaticFieldLeak")
    private void getDataFromDatabase() {
        // AsyncTask is used that SQLite operation runs in background
        // deprecated but I don't know what else to use...
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                listItems.clear();
                listItems.addAll(inventoryDatabase.getAllItems());
                return null;
            }
            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                itemsRecyclerAdapter.notifyDataSetChanged();
                // send notification if any item is less than 5
                for (int i = 0; i < listItems.size(); i++) {
                    if (Integer.parseInt(listItems.get(i).getQuantity()) < 5) {
                        sendSmsMessage(mPhoneNumber, "Your supply of " + listItems.get(i).getName() +
                                " is running low! @Inventory App");
                    }
                }
            }
        }.execute();
    }

    // handle button clicks
    public void onClick(View view) {
            // "Add Item" button to navigate to AddActivity
            if (view.getId() == R.id.addItemButton) {
                Intent intentAddItem = new Intent(this, AddActivity.class);
                intentAddItem.putExtra("USERNAME", textViewName.getText().toString().trim());
                startActivity(intentAddItem);
            }
            // "clear inventory" button to remove all items from database table
            if (view.getId() == R.id.clearInventoryButton) {
                inventoryDatabase.clearDatabase("inventory");
                Toast.makeText(getApplicationContext(), getString(R.string.inventory_cleared), Toast.LENGTH_LONG).show();
                Intent intentClear = new Intent(this, InventoryActivity.class);
                intentClear.putExtra("USERNAME", InventoryActivity.getNameFromIntent());
                startActivity(intentClear);
            }
        }

    // method to send SMS notification
    public void sendSmsMessage(String phoneNum, String message) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
        {
            try
            {
                SmsManager smsMgr = SmsManager.getDefault();
                smsMgr.sendTextMessage(phoneNum, null, message, null, null);
            }
            catch (Exception Err)
            {
                Err.printStackTrace();
            }
        }

    }
    }