/*
 * Inventory App
 * Developed by Mattthew Neale
 * Version 1.0
 * last updated 6/23/2021
 */
package com.mneale.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.mneale.inventoryapp.model.Item;

import java.util.ArrayList;
import java.util.List;

// database for inventory items
public class InventoryDatabase extends SQLiteOpenHelper {
    // database name
    private static final String DATABASE_NAME = "inventory.db";

    // database version
    private static final int VERSION = 1;

    // table name
    private static final String TABLE = "inventory";

    // table column names
    private static final String COL_ID = "_id";
    private static final String COL_NAME = "name";
    private static final String COL_DESCRIPTION = "description";
    private static final String COL_QUANTITY = "quantity";

    // inventory database constructor
    public InventoryDatabase (Context context) {
        super(context, DATABASE_NAME, null, VERSION);


    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE + " (" +
                COL_ID + " integer primary key autoincrement, " +
                COL_NAME + " text, " +
                COL_DESCRIPTION + " text, " +
                COL_QUANTITY + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + TABLE);
        onCreate(db);
    }

    // method to add item to the database
    public void addItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, item.getName());
        values.put(COL_DESCRIPTION, item.getDescription());
        values.put(COL_QUANTITY, item.getQuantity());
        // Inserting Row
        db.insert(TABLE, null, values);
        db.close();
    }
    // return a list of all items
    public List<Item> getAllItems() {
        String[] columns = {
                COL_ID,
                COL_NAME,
                COL_DESCRIPTION,
                COL_QUANTITY
        };

        // sorting orders
        String sortOrder =
                COL_NAME + " ASC";
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // query the login table
        Cursor cursor = db.query(TABLE, //Table to query
                columns,             //columns to return
                null,        //columns for the WHERE clause
                null,     //values for the WHERE clause
                null,        //group the rows
                null,         //filter by row groups
                sortOrder);         //The sort order
        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Item item = new Item();
                item.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COL_ID))));
                item.setName(cursor.getString(cursor.getColumnIndex(COL_NAME)));
                item.setDescription(cursor.getString(cursor.getColumnIndex(COL_DESCRIPTION)));
                item.setQuantity(cursor.getString((cursor.getColumnIndex(COL_QUANTITY))));
                // Adding item record to list
                itemList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        // return item list
        return itemList;
    }
    // update an items information
    public void updateItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, item.getName());
        values.put(COL_DESCRIPTION, item.getDescription());
        values.put(COL_QUANTITY, item.getQuantity());
        // updating row
        db.update(TABLE, values, COL_ID + " = ?",
                new String[]{String.valueOf(item.getId())});
        db.close();
    }
    // delete an item
    public void deleteItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        // delete item record by id
        db.delete(TABLE, COL_ID + " = ?",
                new String[]{String.valueOf(item.getId())});
        db.close();
    }
    // check if an item exists by name
    public boolean checkItem(String name) {
        // array of columns to fetch
        String[] columns = {
                COL_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = COL_NAME + " = ?";
        // selection argument
        String[] selectionArgs = {name};
        // query user table with condition
        Cursor cursor = db.query(TABLE, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,               //group the rows
                null,                //filter by row groups
                null);              //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        return cursorCount > 0;
    }
    // clear database information
    public void clearDatabase(String TABLE_NAME) {
        SQLiteDatabase db = this.getWritableDatabase();
        String clearDBQuery = "DELETE FROM " + TABLE_NAME;
        db.execSQL(clearDBQuery);
    }
}
