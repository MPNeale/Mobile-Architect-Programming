/*
 * Inventory App
 * Developed by Mattthew Neale
 * Version 1.0
 * last updated 6/23/2021
 */
package com.mneale.inventoryapp;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.mneale.inventoryapp.model.Item;

import org.jetbrains.annotations.NotNull;

import java.util.List;

// adapter for recycler view
public class ItemsRecyclerAdapter extends RecyclerView.Adapter<ItemsRecyclerAdapter.ItemViewHolder> {
    private final List<Item> listItems;

    // recycler adapter
    public ItemsRecyclerAdapter(List<Item> listItems) {
        this.listItems = listItems;
    }
    @NotNull
    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // inflating recycler item view
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_recycler, parent, false);
        return new ItemViewHolder(itemView);
    }
    // bind items to view holder
    @Override
    public void onBindViewHolder(ItemViewHolder holder, int position) {
        Item item = listItems.get(position);
        holder.textViewName.setText(listItems.get(position).getName());
        holder.textViewDescription.setText(listItems.get(position).getDescription());
        holder.textViewQuantity.setText(listItems.get(position).getQuantity());
        holder.position = position;
        holder.item = item;
    }
    // return number of items in list
    @Override
    public int getItemCount() {
        Log.v(ItemsRecyclerAdapter.class.getSimpleName(),""+listItems.size());
        return listItems.size();
    }
    // ViewHolder class
    public static class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView textViewName;
        public TextView textViewDescription;
        public TextView textViewQuantity;
        public ImageButton editItemButton;
        public ImageButton deleteItemButton;
        public int position;
        public Item item;
        private final Context context;
        private final InventoryDatabase inventoryDatabase;

        // initialize views for view holder
        public ItemViewHolder(View view) {
            super(view);
            context = view.getContext();

            inventoryDatabase = new InventoryDatabase(context);
            textViewName = view.findViewById(R.id.textViewName);
            textViewDescription = view.findViewById(R.id.textViewDescription);
            textViewQuantity = view.findViewById(R.id.textViewQuantity);
            editItemButton = view.findViewById(R.id.editItemButton);
            deleteItemButton = view.findViewById(R.id.deleteItemButton);

            editItemButton.setOnClickListener(this);
            deleteItemButton.setOnClickListener(this);
        }

        // handle click functions
        @Override
        public void onClick(View view) {
                if (view.getId() == R.id.editItemButton) {
                    Intent intentEdit = new Intent(context, EditActivity.class);
                    intentEdit.putExtra("ITEM_ID", item.getId());
                    intentEdit.putExtra("ITEM_NAME", textViewName.getText().toString().trim());
                    intentEdit.putExtra("ITEM_DESC", textViewDescription.getText().toString().trim());
                    intentEdit.putExtra("ITEM_QUAN", textViewQuantity.getText().toString().trim());
                    context.startActivity(intentEdit);
                }
                if (view.getId() == R.id.deleteItemButton) {
                    inventoryDatabase.deleteItem(item);
                    Toast.makeText(context.getApplicationContext(), "Item deleted!", Toast.LENGTH_SHORT).show();
                    Intent intentDelete = new Intent(context, InventoryActivity.class);
                    context.startActivity(intentDelete);
                }
            }
        }
        }