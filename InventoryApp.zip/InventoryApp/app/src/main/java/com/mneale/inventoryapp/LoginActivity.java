/*
  Inventory App
  Developed by Mattthew Neale
  Version 1.0
  last updated 6/23/2021
 */
package com.mneale.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

// activity for login screen
public class LoginActivity extends AppCompatActivity implements View.OnClickListener{
    private final AppCompatActivity activity = LoginActivity.this;

    // views and buttons
    private EditText textInputUsername;
    private EditText textInputPassword;
    private Button loginButton;
    private Button newUserButton;
    private Button clearUsersButton;

    private LoginDatabase loginDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initializeViews();
        initializeListeners();
        initializeDatabase();
    }

    // initialize the views
    private void initializeViews() {
        textInputUsername = findViewById(R.id.usernameText);
        textInputPassword = findViewById(R.id.passwordText);
        loginButton = findViewById(R.id.submitButton);
        newUserButton = findViewById(R.id.newUserButton);
        clearUsersButton = findViewById(R.id.clearUsersButton);
    }

    // initialize the listeners
    private void initializeListeners() {
        loginButton.setOnClickListener(this);
        newUserButton.setOnClickListener(this);
        clearUsersButton.setOnClickListener(this);
    }

    // initialize the database
    private void initializeDatabase() {
        loginDatabase = new LoginDatabase(activity);
    }

    // verify input against database
    private void verifyFromDatabase() {
        // check if username or password is empty
        if (TextUtils.isEmpty(textInputUsername.getText().toString().trim()) || TextUtils.isEmpty(textInputPassword.getText().toString().trim())) {
            // Toast message that username or password cannot be empty
            Toast.makeText(getApplicationContext(), getString(R.string.error_username_password), Toast.LENGTH_LONG).show();
        // check if username and password match a record in database
        } else if (loginDatabase.checkUser(textInputUsername.getText().toString().trim(),
                    textInputPassword.getText().toString().trim())) {
                Intent intentLogin = new Intent(this, InventoryActivity.class);
                intentLogin.putExtra("USERNAME", textInputUsername.getText().toString().trim());
                startActivity(intentLogin);
            } else {
                // Toast message that info is incorrect
                Toast.makeText(getApplicationContext(), getString(R.string.error_invalid_credentials), Toast.LENGTH_LONG).show();
            }
    }

    public void onClick (View view) {
        if (view.getId() == R.id.submitButton) {
            verifyFromDatabase();
        }
        if (view.getId() == R.id.newUserButton) {
            Intent intentNewUser = new Intent(this, NewUserActivity.class);
            startActivity(intentNewUser);
        }
        if (view.getId() == R.id.clearUsersButton) {
            loginDatabase.clearDatabase("login");
        Toast.makeText(getApplicationContext(), getString(R.string.users_cleared), Toast.LENGTH_LONG).show();
        }
        }
    }