/*
 * Inventory App
 * Developed by Mattthew Neale
 * Version 1.0
 * last updated 6/23/2021
 */
package com.mneale.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.mneale.inventoryapp.model.User;

public class LoginDatabase extends SQLiteOpenHelper {

    // database name
    private static final String DATABASE_NAME = "login.db";

    // database version
    private static final int VERSION = 1;

    // table name
    private static final String TABLE = "login";

    // table column names
    private static final String COL_ID = "_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // database constructor
    public LoginDatabase (Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE + " (" +
                COL_ID + " integer primary key autoincrement, " +
                COL_USERNAME + " text, " +
                COL_PASSWORD + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + TABLE);
        onCreate(db);
    }

    // method to add user to the database
    public void addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, user.getName());
        values.put(COL_PASSWORD, user.getPassword());
        // Inserting Row
        db.insert(TABLE, null, values);
        db.close();
    }

    // check if a user exists by username and password
    public boolean checkUser(String username, String password) {
        // array of columns to fetch
        String[] columns = {
                COL_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = COL_USERNAME + " = ?" + " AND " + COL_PASSWORD + " = ?";
        // selection argument
        String[] selectionArgs = {username, password};
        // query user table with condition
        Cursor cursor = db.query(TABLE, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        return cursorCount > 0;
    }
    // check if a user exists by username
    public boolean checkUser(String username) {
        // array of columns to fetch
        String[] columns = {
                COL_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = COL_USERNAME + " = ?";
        // selection argument
        String[] selectionArgs = {username};
        // query user table with condition
        Cursor cursor = db.query(TABLE, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        return cursorCount > 0;
    }
    // clear login database information
    public void clearDatabase(String TABLE_NAME) {
        SQLiteDatabase db = this.getWritableDatabase();
        String clearDBQuery = "DELETE FROM " + TABLE_NAME;
        db.execSQL(clearDBQuery);
    }
}
