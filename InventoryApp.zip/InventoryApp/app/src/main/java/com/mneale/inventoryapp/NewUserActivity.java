/*
 * Inventory App
 * Developed by Mattthew Neale
 * Version 1.0
 * last updated 6/23/2021
 */
package com.mneale.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mneale.inventoryapp.model.User;

// activity for new user screen
public class NewUserActivity extends AppCompatActivity implements View.OnClickListener {
    private final AppCompatActivity activity = NewUserActivity.this;

    // views, buttons, and other goodies
    private EditText textInputUsername;
    private EditText textInputPassword;
    private EditText textInputConfirmPassword;
    private Button createNewUserButton;
    private Button returnToLoginButton;

    private LoginDatabase loginDatabase;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user);

        initializeViews();
        initializeListeners();
        initializeDatabase();
    }

    // initialize the views
    private void initializeViews() {
        textInputUsername = findViewById(R.id.usernameText);
        textInputPassword = findViewById(R.id.passwordText);
        textInputConfirmPassword = findViewById(R.id.confirmPasswordText);
        createNewUserButton = findViewById(R.id.createNewUserButton);
        returnToLoginButton = findViewById(R.id.returnToLoginButton);
    }
    // initialize the listeners
    private void initializeListeners() {
        createNewUserButton.setOnClickListener(this);
        returnToLoginButton.setOnClickListener(this);
    }
    // initialize the database
    private void initializeDatabase() {
        loginDatabase = new LoginDatabase(activity);
        user = new User();
    }
    // add new user to SQLite database
    // Utilizes addUser() method from LoginDatabase
    private void addToDatabase() {
        // check if username, password, or confirm password fields are empty
        if (TextUtils.isEmpty(textInputPassword.getText().toString().trim()) || TextUtils.isEmpty(textInputUsername.getText().toString().trim()) ||
                TextUtils.isEmpty(textInputConfirmPassword.getText().toString().trim())) {
            // display toast message to enter username and password
            Toast.makeText(getApplicationContext(), getString(R.string.error_username_password), Toast.LENGTH_LONG).show();
        // check if password and confirm password match
        } else if (!textInputPassword.getText().toString().trim().equals(textInputConfirmPassword.getText().toString().trim())) {
                Toast.makeText(getApplicationContext(), getString(R.string.error_passwords_do_not_match), Toast.LENGTH_LONG).show();
            // check if user already exists in database
            } else if (!loginDatabase.checkUser(textInputUsername.getText().toString().trim())) {
                user.setName(textInputUsername.getText().toString().trim());
                user.setPassword(textInputPassword.getText().toString().trim());
                // add new user to the database
                loginDatabase.addUser(user);
                Toast.makeText(getApplicationContext(), getString(R.string.user_created), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), getString(R.string.error_user_already_exists), Toast.LENGTH_LONG).show();
            }
    }
    // set onClick functions
    public void onClick(View view) {
            if (view.getId() == R.id.createNewUserButton) {
                addToDatabase();
            }
            if (view.getId() == R.id.returnToLoginButton) {
                Intent intentReturn = new Intent(this, LoginActivity.class);
                startActivity(intentReturn);
            }
    }
}