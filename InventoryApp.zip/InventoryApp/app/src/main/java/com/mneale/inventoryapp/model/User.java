/*
 * Inventory App
 * Developed by Mattthew Neale
 * Version 1.0
 * last updated 6/23/2021
 */
package com.mneale.inventoryapp.model;

// User class to hold user information for each user in database
// used to populate database of users for LoginActivity
public class User {

    // parameters for user object
    private int id;
    private String name;
    private String password;

    // setters and getters for user object
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
}
